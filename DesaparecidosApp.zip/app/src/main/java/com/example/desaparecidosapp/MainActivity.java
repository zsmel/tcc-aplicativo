
package com.example.desaparecidosapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editNome, editData;
    Button btnSalvar;
    ListView listaPessoas;
    PessoaDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNome = findViewById(R.id.editNome);
        editData = findViewById(R.id.editData);
        btnSalvar = findViewById(R.id.btnSalvar);
        listaPessoas = findViewById(R.id.listaPessoas);

        dao = new PessoaDAO(this);

        btnSalvar.setOnClickListener(v -> {
            String nome = editNome.getText().toString();
            String data = editData.getText().toString();
            dao.inserir(nome, data);
            Toast.makeText(this, "Salvo com sucesso!", Toast.LENGTH_SHORT).show();
            listar();
        });

        listar();
    }

    private void listar() {
        List<PessoaDesaparecida> lista = dao.listar();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1);
        for (PessoaDesaparecida p : lista) {
            adapter.add(p.getNome() + " - " + p.getDataDesaparecimento());
        }
        listaPessoas.setAdapter(adapter);
    }
}
