
package com.example.desaparecidosapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {
    private SQLiteDatabase banco;

    public PessoaDAO(Context context) {
        BancoHelper helper = new BancoHelper(context);
        banco = helper.getWritableDatabase();
    }

    public void inserir(String nome, String data) {
        ContentValues valores = new ContentValues();
        valores.put(BancoHelper.COL_NOME, nome);
        valores.put(BancoHelper.COL_DATA, data);
        banco.insert(BancoHelper.TABELA, null, valores);
    }

    public List<PessoaDesaparecida> listar() {
        List<PessoaDesaparecida> lista = new ArrayList<>();
        Cursor cursor = banco.query(BancoHelper.TABELA,
                null, null, null, null, null, BancoHelper.COL_ID + " DESC");

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(BancoHelper.COL_ID));
            String nome = cursor.getString(cursor.getColumnIndexOrThrow(BancoHelper.COL_NOME));
            String data = cursor.getString(cursor.getColumnIndexOrThrow(BancoHelper.COL_DATA));
            lista.add(new PessoaDesaparecida(id, nome, data));
        }
        cursor.close();
        return lista;
    }
}
