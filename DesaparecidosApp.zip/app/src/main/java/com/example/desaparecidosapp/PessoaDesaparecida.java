
package com.example.desaparecidosapp;

public class PessoaDesaparecida {
    private int id;
    private String nome;
    private String dataDesaparecimento;

    public PessoaDesaparecida(int id, String nome, String dataDesaparecimento) {
        this.id = id;
        this.nome = nome;
        this.dataDesaparecimento = dataDesaparecimento;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDataDesaparecimento() { return dataDesaparecimento; }
}
