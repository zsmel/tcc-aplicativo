package com.example.reconhecimentofacial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class FormCadastroAdm extends AppCompatActivity {

    private TextView text_tela_cadastro_adm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_cadastro_adm);
    }

    private void IniciarComponentes(){
        text_tela_cadastro_adm = findViewById(R.id.text_tela_cadastro_adm);
    }
}